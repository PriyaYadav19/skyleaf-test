package com.jspiders.repository;

import org.springframework.data.repository.CrudRepository;

import com.jspiders.bean.Card;

public interface CardRepository  extends CrudRepository<Card,String>{

}
