package com.jspiders.repository;

import org.springframework.data.repository.CrudRepository;

import com.jspiders.bean.BillingDetails;

public interface BillingDetailsRepository  extends CrudRepository<BillingDetails, String>   {

}
