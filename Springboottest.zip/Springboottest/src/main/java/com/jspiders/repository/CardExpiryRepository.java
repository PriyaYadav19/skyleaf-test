package com.jspiders.repository;

import org.springframework.data.repository.CrudRepository;

import com.jspiders.bean.CardExpiry;

public interface CardExpiryRepository  extends CrudRepository<CardExpiry,String> {

}
