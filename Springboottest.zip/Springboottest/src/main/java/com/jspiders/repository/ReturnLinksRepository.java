package com.jspiders.repository;

import org.springframework.data.repository.CrudRepository;

import com.jspiders.bean.ReturnLinks;

public interface ReturnLinksRepository extends CrudRepository<ReturnLinks,String>
{

}
