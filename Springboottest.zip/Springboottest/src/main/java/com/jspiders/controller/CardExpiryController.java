package com.jspiders.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jspiders.bean.CardExpiry;
import com.jspiders.bean.PaymentMethod;
import com.jspiders.repository.CardExpiryRepository;
import com.jspiders.repository.PaymentMethodRepository;

@RequestMapping("/cardexpiry")
@RestController
public class CardExpiryController {
	
	@Autowired
	private  CardExpiryRepository repository;
	
	@GetMapping("/readAll")
	public  Iterable<CardExpiry> readAll()
	{
		Iterable<CardExpiry> all= repository.findAll();
		return all;
	}
	
	@PostMapping("/create")
	public  CardExpiry create (@RequestBody CardExpiry cardexpiry)
	{
		return repository.save(cardexpiry);
		
	}
	
	@GetMapping("/read/{id}")
	public Optional<CardExpiry> read(@PathVariable String id)
	{
		return  repository.findById(id);
		
}
	
	@PutMapping("/update")
	
		public CardExpiry update(@RequestBody CardExpiry cardexpiry )
		{
			return  repository.save(cardexpiry);
		}
	
	@DeleteMapping("/delete/{id}")
	public  void delete(@PathVariable String id)
	{
	repository.deleteById(id);
	
	
	
}
}