package com.jspiders.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jspiders.bean.BillingDetails;
import com.jspiders.repository.BillingDetailsRepository;



@RequestMapping("/billingdetails")
@RestController
public class BillingDetailsController {

	
	
	
	@Autowired
	private  BillingDetailsRepository repository;
	
	@GetMapping("/readAll")
	public  Iterable<BillingDetails> readAll()
	{
		Iterable<BillingDetails> all= repository.findAll();
		return all;
	}
	
	@PostMapping("/create")
	public BillingDetails create (@RequestBody BillingDetails billingdetails)
	{
		return repository.save(billingdetails);
		
	}
	
	@GetMapping("/read/{id}")
	public Optional<BillingDetails> read(@PathVariable String id)
	{
		return  repository.findById(id);
		
}
	
	@PutMapping("/update")
	
		public BillingDetails update(@RequestBody BillingDetails billingdetails )
		{
			return  repository.save(billingdetails);
		}
	
	@DeleteMapping("/delete/{id}")
	public  void delete(@PathVariable String id)
	{
	repository.deleteById(id);
	
}
}