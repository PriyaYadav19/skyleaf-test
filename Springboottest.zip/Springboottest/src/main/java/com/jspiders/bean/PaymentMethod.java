package com.jspiders.bean;

import javax.persistence.Entity;

import javax.persistence.Id;

//import org.springframework.beans.factory.annotation.Autowired;

@Entity
public class PaymentMethod {

	@Id
	private String id;
	private int  amount;
	private  String merchantrefnum;
	private  String action;
	private  String currencycode;
	private  String usage;
	private  String status;
	private  String timetoliveseconds;
	private  String transcationtype;
	private  String paymenttype;
	private  String executionmode;
	private  String  customerip;
	private  String  paymenthandletoken;
	//@Autowired
	//private  BillingDetails billingDetails;
	//@Autowired
	//private  Card  card;
	//private  ReturnLinks  returnLinks;
	

	/*
	 * public BillingDetails getBillingDetails() { return billingDetails; } public
	 * void setBillingDetails(BillingDetails billingDetails) { this.billingDetails =
	 * billingDetails; } public Card getCard() { return card; } public void
	 * setCard(Card card) { this.card = card; } public ReturnLinks getReturnLinks()
	 * { return returnLinks; } public void setReturnLinks(ReturnLinks returnLinks) {
	 * this.returnLinks = returnLinks; }
	 */
	/*
	 * @Override public String toString() { return "PaymentMethod [id=" + id +
	 * ", amount=" + amount + ", merchantRefNum=" + merchantRefNum + ", action=" +
	 * action + ", currencyCode=" + currencyCode + ", usage=" + usage + ", status="
	 * + status + ", timeToLiveSeconds=" + timeToLiveSeconds + ", transcationType="
	 * + transcationType + ", paymentType=" + paymentType + ", executionMode=" +
	 * executionMode + ", customerIp=" + customerIp + ", paymentHandleToken=" +
	 * paymentHandleToken + ",]"; }
	 */

	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public int getAmount() {
		return amount;
	}


	public void setAmount(int amount) {
		this.amount = amount;
	}


	public String getMerchantrefnum() {
		return merchantrefnum;
	}


	public void setMerchantrefnum(String merchantrefnum) {
		this.merchantrefnum = merchantrefnum;
	}


	public String getAction() {
		return action;
	}


	public void setAction(String action) {
		this.action = action;
	}


	public String getCurrencycode() {
		return currencycode;
	}


	public void setCurrencycode(String currencycode) {
		this.currencycode = currencycode;
	}


	public String getUsage() {
		return usage;
	}


	public void setUsage(String usage) {
		this.usage = usage;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getTimetoliveseconds() {
		return timetoliveseconds;
	}


	public void setTimetoliveseconds(String timetoliveseconds) {
		this.timetoliveseconds = timetoliveseconds;
	}


	public String getTranscationtype() {
		return transcationtype;
	}


	public void setTranscationtype(String transcationtype) {
		this.transcationtype = transcationtype;
	}


	public String getPaymenttype() {
		return paymenttype;
	}


	public void setPaymenttype(String paymenttype) {
		this.paymenttype = paymenttype;
	}


	public String getExecutionmode() {
		return executionmode;
	}


	public void setExecutionmode(String executionmode) {
		this.executionmode = executionmode;
	}


	public String getCustomerip() {
		return customerip;
	}


	public void setCustomerip(String customerip) {
		this.customerip = customerip;
	}


	public String getPaymenthandletoken() {
		return paymenthandletoken;
	}


	public void setPaymenthandletoken(String paymenthandletoken) {
		this.paymenthandletoken = paymenthandletoken;
	}


	@Override
	public String toString() {
		return "PaymentMethod [id=" + id + ", amount=" + amount + ", merchantrefnum=" + merchantrefnum + ", action="
				+ action + ", currencycode=" + currencycode + ", usage=" + usage + ", status=" + status
				+ ", timetoliveseconds=" + timetoliveseconds + ", transcationtype=" + transcationtype + ", paymenttype="
				+ paymenttype + ", executionmode=" + executionmode + ", customerip=" + customerip
				+ ", paymenthandletoken=" + paymenthandletoken + "]";
	}
	
}

